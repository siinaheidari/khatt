'use client'

import appLogo from "../../../public/images/appLogo.svg"
import Image from "next/image";
import {forwardRef, PropsWithChildren} from "react";

// Custom ref type (if you are expecting a scrollbar instance)
interface ScrollbarElement extends HTMLDivElement {
  scrollbar?: {
    scrollIntoView: (element: HTMLElement, options: {
      offsetTop: number,
      damping: number
    }) => void;
  };
}

const Header = forwardRef<ScrollbarElement, PropsWithChildren>(({children}, ref) => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element && ref && 'current' in ref && ref.current) {
      const scrollbar = ref.current.scrollbar;
      if (scrollbar) {
        scrollbar.scrollIntoView(element, {
          offsetTop: 0, // Adjust this offset as needed
          damping: 0.1, // Smoothing effect
        });
      }
    }
  };

  return (
    <>
      <div className={"flex justify-between items-center pt-[20px] pb-8 px-[39px]"}>
        <Image src={appLogo} alt={'appLogo'} className={""}/>
        <div
          className={"flex justify-center gap-[32px] text-neutral text-buttonTextSmall group group-hover:text-primary-dark [&>a]:text-white [&>div]:cursor-pointer group "}>
          <div onClick={() => scrollToSection('aboutUS')} className={"hover:text-primary-dark"}>
            درباره ما
          </div>

          <div onClick={() => scrollToSection('whatWeDo')} className={"hover:text-primary-dark"}>
            خدمات
          </div>

          <div onClick={() => scrollToSection('services')} className={"hover:text-primary-dark"}>
            نمونه کارها
          </div>

          <div onClick={() => scrollToSection('contactUs')} className={"hover:text-primary-dark"}>
            تماس با ما
          </div>
        </div>
        <div className={"text-white text-buttonTextSmall hover:text-primary-dark"} >
          EN
        </div>
      </div>
      <div className={"bg-[linear-gradient(90deg,#5D5D5D_0%,#888_50%,#5D5D5D_100%)] w-full h-[1px]"}/>
    </>
  );
});

export default Header;
